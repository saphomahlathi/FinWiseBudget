package com.finwisebank.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Expense::class, User::class], version = 2)
abstract class AppDatabase : RoomDatabase() {
    abstract fun expenseDao(): ExpenseDao
    abstract fun userDao(): UserDao
}