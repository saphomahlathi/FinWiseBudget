package com.finwisebank.data

data class CategoryTotal(
    val category: String,
    val total: Double
)