package com.finwisebank.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.finwisebank.data.Expense
import com.finwisebank.utils.DatabaseInstance
import com.finwisebank.utils.SmartCategory
import kotlinx.coroutines.*

class AddExpenseActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_expense)

        db = DatabaseInstance.getDatabase(this)

        val title = findViewById<EditText>(R.id.edtTitle)
        val amount = findViewById<EditText>(R.id.edtAmount)
        val category = findViewById<Spinner>(R.id.spinnerCategory)

        findViewById<Button>(R.id.btnSave).setOnClickListener {

            val amountValue = amount.text.toString().toDoubleOrNull() ?: 0.0
            val categoryText = SmartCategory.detectCategory(title.text.toString())

            val expense = Expense(
                title = title.text.toString(),
                amount = amountValue,
                category = categoryText,
                date = System.currentTimeMillis().toString()
            )

            CoroutineScope(Dispatchers.IO).launch {
                db.expenseDao().insert(expense)
                finish()
            }
        }
    }
}