package com.finwisebank.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.finwisebank.utils.DatabaseInstance
import com.finwisebank.utils.BudgetCalculator
import kotlinx.coroutines.*

class DashboardActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        db = DatabaseInstance.getDatabase(this)

        loadDashboard()

        findViewById<Button>(R.id.btnAddExpense).setOnClickListener {
            startActivity(Intent(this, AddExpenseActivity::class.java))
        }

        findViewById<Button>(R.id.btnGraph).setOnClickListener {
            startActivity(Intent(this, GraphActivity::class.java))
        }

        findViewById<Button>(R.id.btnReport).setOnClickListener {
            startActivity(Intent(this, MonthlyReportActivity::class.java))
        }
    }

    private fun loadDashboard() {

        CoroutineScope(Dispatchers.IO).launch {

            val total = db.expenseDao().getTotalSpent() ?: 0.0
            val budget = 5000.0

            val score = BudgetCalculator.calculateScore(total, budget)

            withContext(Dispatchers.Main) {
                findViewById<TextView>(R.id.txtTotalSpent).text =
                    "Total Spent: R$total"

                findViewById<TextView>(R.id.txtScore).text =
                    "Wallet Score: $score"
            }
        }
    }
}