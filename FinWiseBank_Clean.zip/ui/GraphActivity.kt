package com.finwisebank.ui

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.*
import com.finwisebank.utils.DatabaseInstance
import kotlinx.coroutines.*

class GraphActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_graph)

        db = DatabaseInstance.getDatabase(this)

        loadGraph()
    }

    private fun loadGraph() {

        CoroutineScope(Dispatchers.IO).launch {

            val data = db.expenseDao().getCategoryTotals()

            val entries = ArrayList<BarEntry>()
            val labels = ArrayList<String>()

            var index = 0f
            for (item in data) {
                entries.add(BarEntry(index, item.total.toFloat()))
                labels.add(item.category)
                index++
            }

            val dataSet = BarDataSet(entries, "Expenses")
            dataSet.color = Color.GREEN

            val barData = BarData(dataSet)

            withContext(Dispatchers.Main) {
                val chart = findViewById<BarChart>(R.id.barChart)
                chart.data = barData
                chart.animateY(1000)
                chart.invalidate()
            }
        }
    }
}