package com.finwisebank.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.finwisebank.utils.DatabaseInstance
import com.finwisebank.data.User
import kotlinx.coroutines.*

class LoginActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        db = DatabaseInstance.getDatabase(this)

        val username = findViewById<EditText>(R.id.edtUsername)
        val password = findViewById<EditText>(R.id.edtPassword)

        findViewById<Button>(R.id.btnRegister).setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                db.userDao().register(
                    User(username = username.text.toString(),
                         password = password.text.toString())
                )
            }
        }

        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            CoroutineScope(Dispatchers.IO).launch {
                val user = db.userDao().login(
                    username.text.toString(),
                    password.text.toString()
                )

                withContext(Dispatchers.Main) {
                    if (user != null) {
                        startActivity(Intent(this@LoginActivity, DashboardActivity::class.java))
                        finish()
                    } else {
                        Toast.makeText(this@LoginActivity, "Invalid login", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
}