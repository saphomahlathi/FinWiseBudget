package com.finwisebank.ui

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.finwisebank.utils.DatabaseInstance
import kotlinx.coroutines.*

class MonthlyReportActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthly_report)

        db = DatabaseInstance.getDatabase(this)

        generateReport()
    }

    private fun generateReport() {

        CoroutineScope(Dispatchers.IO).launch {

            val total = db.expenseDao().getTotalSpent() ?: 0.0
            val avg = total / 30

            val advice = when {
                total < 2000 -> "Good job! You are saving well."
                total < 5000 -> "Try reducing unnecessary spending."
                else -> "Warning: Overspending detected!"
            }

            withContext(Dispatchers.Main) {
                findViewById<TextView>(R.id.txtTotal).text =
                    "Total Spent: R$total"

                findViewById<TextView>(R.id.txtAvg).text =
                    "Daily Average: R$avg"

                findViewById<TextView>(R.id.txtAdvice).text =
                    advice
            }
        }
    }
}