package com.finwisebank.ui

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.finwisebank.utils.DatabaseInstance
import kotlinx.coroutines.*

class RewardsActivity : AppCompatActivity() {

    private lateinit var db: com.finwisebank.data.AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rewards)

        db = DatabaseInstance.getDatabase(this)

        showBadge()
    }

    private fun showBadge() {

        CoroutineScope(Dispatchers.IO).launch {

            val total = db.expenseDao().getTotalSpent() ?: 0.0
            val budget = 5000.0

            val badge = when {
                total < budget * 0.5 -> "🏆 Saver Master"
                total < budget -> "💰 Good Control"
                else -> "⚠ Overspender"
            }

            withContext(Dispatchers.Main) {
                findViewById<TextView>(R.id.txtBadge).text = badge
            }
        }
    }
}