package com.finwisebank.utils

object BudgetCalculator {

    fun calculateScore(totalSpent: Double, budget: Double): Int {
        if (budget == 0.0) return 0

        val ratio = totalSpent / budget

        return when {
            ratio < 0.5 -> 900
            ratio < 0.8 -> 750
            ratio <= 1.0 -> 600
            else -> 300
        }
    }
}