package com.finwisebank.utils

import android.content.Context
import androidx.room.Room
import com.finwisebank.data.AppDatabase

object DatabaseInstance {

    private var instance: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
        return instance ?: Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "finwise_db"
        ).build().also {
            instance = it
        }
    }
}