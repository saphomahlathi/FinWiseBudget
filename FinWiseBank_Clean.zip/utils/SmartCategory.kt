package com.finwisebank.utils

object SmartCategory {

    fun detectCategory(text: String): String {

        val input = text.lowercase()

        return when {
            input.contains("uber") || input.contains("taxi") -> "Transport"
            input.contains("shop") || input.contains("food") -> "Food"
            input.contains("electric") || input.contains("water") -> "Bills"
            input.contains("movie") || input.contains("netflix") -> "Entertainment"
            else -> "Other"
        }
    }
}