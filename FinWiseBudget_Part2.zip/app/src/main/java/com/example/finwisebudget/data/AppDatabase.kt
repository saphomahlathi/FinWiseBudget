package com.example.finwisebudget.data
import androidx.room.*
import android.content.Context

@Database(entities=[User::class,Category::class,Expense::class,Goal::class],version=1)
abstract class AppDatabase:RoomDatabase(){
abstract fun userDao():UserDao
abstract fun categoryDao():CategoryDao
abstract fun expenseDao():ExpenseDao
abstract fun goalDao():GoalDao

companion object{
@Volatile private var INSTANCE:AppDatabase?=null
fun getDatabase(context:Context):AppDatabase{
return INSTANCE?:synchronized(this){
val instance=Room.databaseBuilder(context,AppDatabase::class.java,"finwise_database").build()
INSTANCE=instance
instance
}}}}
