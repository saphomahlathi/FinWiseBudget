package com.example.finwisebudget.data
import androidx.room.*

@Entity(tableName="categories")
data class Category(@PrimaryKey(autoGenerate=true) val id:Int=0,val categoryName:String)
