package com.example.finwisebudget.data
import androidx.room.*

@Entity(tableName="expenses")
data class Expense(@PrimaryKey(autoGenerate=true) val id:Int=0,val amount:Double,val description:String,val date:String,val startTime:String,val endTime:String,val categoryId:Int,val imageUri:String?)
