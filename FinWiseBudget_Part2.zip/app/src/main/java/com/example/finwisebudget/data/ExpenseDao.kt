package com.example.finwisebudget.data
import androidx.room.*

@Dao
interface ExpenseDao {
@Insert suspend fun insertExpense(expense:Expense)
@Query("SELECT * FROM expenses")
suspend fun getAllExpenses():List<Expense>
@Delete suspend fun deleteExpense(expense:Expense)
}
