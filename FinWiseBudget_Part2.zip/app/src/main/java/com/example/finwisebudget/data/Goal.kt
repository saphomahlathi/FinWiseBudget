package com.example.finwisebudget.data
import androidx.room.*

@Entity(tableName="goals")
data class Goal(@PrimaryKey(autoGenerate=true) val id:Int=0,val minGoal:Double,val maxGoal:Double)
