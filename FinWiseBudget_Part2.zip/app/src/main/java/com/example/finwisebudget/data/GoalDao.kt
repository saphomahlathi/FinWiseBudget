package com.example.finwisebudget.data
import androidx.room.*

@Dao
interface GoalDao {
@Insert suspend fun insertGoal(goal:Goal)
@Query("SELECT * FROM goals LIMIT 1")
suspend fun getGoal():Goal?
}
