package com.example.finwisebudget.data
import androidx.room.*

@Entity(tableName="users")
data class User(@PrimaryKey(autoGenerate=true) val id:Int=0,val username:String,val password:String)
