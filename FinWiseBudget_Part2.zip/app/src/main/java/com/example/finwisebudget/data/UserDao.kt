package com.example.finwisebudget.data
import androidx.room.*

@Dao
interface UserDao {
@Insert suspend fun insertUser(user:User)
@Query("SELECT * FROM users WHERE username=:username AND password=:password")
suspend fun login(username:String,password:String):User?
}
